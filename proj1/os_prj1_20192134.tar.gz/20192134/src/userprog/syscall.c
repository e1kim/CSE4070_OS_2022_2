#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "filesys/file.h"
static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void check_user_vaddr(const void *vaddr){
    if(vaddr == NULL ||!is_user_vaddr(vaddr)){
        exit(-1);  
    }
    void *pointer= pagedir_get_page(thread_current()->pagedir, vaddr);
    if(pointer == NULL)
        exit(-1);
}
static void
syscall_handler (struct intr_frame *f) 
{
    
  switch(*(uint32_t*)(f->esp)){
      case SYS_HALT:
          halt();
          break;
          
      case SYS_EXIT:
          check_user_vaddr(f->esp+4);
          exit(*(uint32_t*)(f->esp+4));
          break;
      case SYS_EXEC:
          check_user_vaddr(f->esp+4);
          f->eax = exec((char*)*(uint32_t*)(f->esp+4));
          break;
      case SYS_WAIT:
          check_user_vaddr(f->esp+4);
          f->eax = wait(*(uint32_t*)(f->esp+4));
          break;
      case SYS_CREATE:
          break;
      case SYS_REMOVE:
          break;
      case SYS_OPEN:
          break;
      case SYS_FILESIZE:
          break;

      case SYS_READ:
          check_user_vaddr(f->esp+4);
          check_user_vaddr(f->esp+8);
          check_user_vaddr(f->esp+12);

          f->eax = read((int)*(uint32_t*)(f->esp+4), (const void*)*(uint32_t*)(f->esp+8), (unsigned)*(uint32_t*)(f->esp+12));
          break;
      case SYS_WRITE:
          check_user_vaddr(f->esp+4);
          check_user_vaddr(f->esp+8);
          check_user_vaddr(f->esp+12);
          f->eax = write((int)*(uint32_t*)(f->esp+4), (const void*)*(uint32_t*)(f->esp+8), (unsigned)*(uint32_t*)(f->esp+12));
          break;
      case SYS_FIBONACCI:
          check_user_vaddr(f->esp+4);
          f->eax = fibonacci((int)*(uint32_t*)(f->esp+4));
          break;
      case SYS_MAX:
          check_user_vaddr(f->esp+4);
          check_user_vaddr(f->esp+8);
          check_user_vaddr(f->esp+12);
          check_user_vaddr(f->esp+16);
          f->eax = max_of_four_int((int)*(uint32_t*)(f->esp+4),(int)*(uint32_t*)(f->esp+8),(int)*(uint32_t*)(f->esp+12),(int)*(uint32_t*)(f->esp+16));
          break;
          }
//  printf ("system call number :%d\n",*(uint32_t*)(f->esp));
//  printf("%s\n",thread_name());
  //  printf("system call!\n");
//  thread_exit ();
}

void halt(void){
    shutdown_power_off();

}
void exit(int status){
    //debug
    printf("%s: exit(%d)\n",thread_name(),status);
    thread_current()->child_status = status;
    thread_exit();

}

pid_t exec(const char *file_name){

    return process_execute(file_name);    

}
int wait(pid_t pid){
    //자식이 끝날때까지 기다려야함.
    return process_wait(pid);
}

int read(int fd,void *buffer, unsigned size){
    
    int i=0;
    if (fd==0){
        
        while(i<(int)size){
       
            if( input_getc()=='\0' )
                break;
            i++;
        }
        return i;
    }
    else return -1;
}

int write(int fd, const void *buffer, unsigned size)
{
    if (fd ==1) {
        putbuf((char*)buffer,(size_t)size)  ;
        return size;
    }
    else
        return -1;
}
int fibonacci(int a){
    if(a==0) return 0;
    else if (a==1) return 1;
    else return fibonacci(a-1)+fibonacci(a-2);
}

int max_of_four_int(int a, int b, int c ,int d){

    
    int max = a;

    if(max < b)  max = b;
    if(max < c) max = c;
    if(max <d) max= d;
    return max;


}
