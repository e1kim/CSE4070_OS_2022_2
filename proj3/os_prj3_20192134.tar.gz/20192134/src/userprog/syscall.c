#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include <string.h>
#include "filesys/off_t.h"
#include "threads/synch.h"


static void syscall_handler (struct intr_frame *);

struct file{
    struct inode *inode;
    off_t pos;
    bool deny_write;

};
void
syscall_init (void) 
{
  lock_init(&file_lock);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void check_user_vaddr(const void *vaddr){
    if(vaddr == NULL ||!is_user_vaddr(vaddr)){
        exit(-1);  
    }
    void *pointer= pagedir_get_page(thread_current()->pagedir, vaddr);
    if(pointer == NULL)
        exit(-1);
}
static void
syscall_handler (struct intr_frame *f) 
{
    
  switch(*(uint32_t*)(f->esp)){
      case SYS_HALT:
          halt();
          break;
          
      case SYS_EXIT:
          check_user_vaddr(f->esp+4);
          exit(*(uint32_t*)(f->esp+4));
          break;
      case SYS_EXEC:
          check_user_vaddr(f->esp+4);
          f->eax = exec((char*)*(uint32_t*)(f->esp+4));
          break;
      case SYS_WAIT:
          check_user_vaddr(f->esp+4);
          f->eax = wait(*(uint32_t*)(f->esp+4));
          break;
      case SYS_CREATE:
          check_user_vaddr(f->esp+4);
          check_user_vaddr(f->esp+8);
          f->eax = create((char*)*(uint32_t*)(f->esp+4),(char*)*(uint32_t*)(f->esp+8));
          break;
      case SYS_REMOVE:
          check_user_vaddr(f->esp+4);
          f->eax = remove(*(uint32_t*)(f->esp+4));
          break;
      case SYS_OPEN:
          check_user_vaddr(f->esp+4);
          f->eax = open(*(uint32_t*)(f->esp+4));
          break;
      case SYS_FILESIZE:
          check_user_vaddr(f->esp+4);
          f->eax = filesize(*(uint32_t*)(f->esp+4));
          break;

      case SYS_READ:
          check_user_vaddr(f->esp+4);
          check_user_vaddr(f->esp+8);
          check_user_vaddr(f->esp+12);

          f->eax = read((int)*(uint32_t*)(f->esp+4), (const void*)*(uint32_t*)(f->esp+8), (unsigned)*(uint32_t*)(f->esp+12));
          break;
      case SYS_WRITE:
          check_user_vaddr(f->esp+4);
          check_user_vaddr(f->esp+8);
          check_user_vaddr(f->esp+12);
          f->eax = write((int)*(uint32_t*)(f->esp+4), (const void*)*(uint32_t*)(f->esp+8), (unsigned)*(uint32_t*)(f->esp+12));
          break;
      case SYS_SEEK:
          check_user_vaddr(f->esp+4);
          check_user_vaddr(f->esp+8);
          seek((char*)*(uint32_t*)(f->esp+4),(char*)*(uint32_t*)(f->esp+8));
            
          break;
      case SYS_TELL:
          check_user_vaddr(f->esp+4);
          f->eax = tell((int)*(uint32_t*)(f->esp+4));  
          break;
      case SYS_CLOSE:
          check_user_vaddr(f->esp+4);
          close((int)*(uint32_t*)(f->esp+4));  
          break;     
      case SYS_FIBONACCI:
          check_user_vaddr(f->esp+4);
          f->eax = fibonacci((int)*(uint32_t*)(f->esp+4));
          break;
      case SYS_MAX:
          check_user_vaddr(f->esp+4);
          check_user_vaddr(f->esp+8);
          check_user_vaddr(f->esp+12);
          check_user_vaddr(f->esp+16);
          f->eax = max_of_four_int((int)*(uint32_t*)(f->esp+4),(int)*(uint32_t*)(f->esp+8),(int)*(uint32_t*)(f->esp+12),(int)*(uint32_t*)(f->esp+16));
          break;
    
          }
//  printf ("system call number :%d\n",*(uint32_t*)(f->esp));
//  printf("%s\n",thread_name());
  //  printf("system call!\n");
//  thread_exit ();
}

void halt(void){
    shutdown_power_off();

}
void exit(int status){
    //debug
    printf("%s: exit(%d)\n",thread_name(),status);
    thread_current()->child_status = status;
    int i=0;
    for(i=3; i<128; ++i){
        if (thread_current()->fd[i] != NULL) close(i);
    }
    thread_exit();

}

pid_t exec(const char *file_name){

    return process_execute(file_name);    

}
int wait(pid_t pid){
    //자식이 끝날때까지 기다려야함.
    return process_wait(pid);
}
bool create(const char *file, unsigned initial_size){
    if (file == NULL) exit(-1);
    return filesys_create(file,initial_size);
}
bool remove(const char *file){
    if (file==NULL) exit(-1);
    return filesys_remove(file);
}

int open(const char* file){
    //filesys_open을 통해 fp를 받고 전달함 넣은 인덱스를 리턴함
    check_user_vaddr(file);  
    if (file == NULL) exit(-1);

    lock_acquire(&file_lock);
    struct file* fp = filesys_open(file);
    
    int i=3;

    if (fp == NULL) {
        lock_release(&file_lock);
        return -1;
    } //fp가 NULL일 경우 -1전달
    else{
        for (i=3; i<128; ++i){
            if (thread_current()->fd[i] == NULL){
                if (!strcmp(thread_current()->name, file)) file_deny_write(fp); //같으면 
                thread_current()->fd[i] = fp; 
                lock_release(&file_lock);
                return i;
            }
        }
    }
    lock_release(&file_lock);
    return -1;
}

int filesize(int fd){
    if(thread_current()->fd[fd] == NULL) exit(-1);
    return file_length(thread_current() -> fd[fd]);
}
int read(int fd,void *buffer, unsigned size){
    check_user_vaddr(buffer);
    lock_acquire(&file_lock);

    if (fd >2 && (thread_current()->fd[fd] == NULL)) {
        lock_release(&file_lock);
        exit(-1);
    }
    int i=0;
    if (fd==0){
        
        while(i<(int)size){
       
            if( input_getc()=='\0' )
                break;
            i++;
        }
        
    }
    else if(fd>2) {
        lock_release(&file_lock);
        return file_read(thread_current()->fd[fd],buffer,size);
    }

    
    lock_release(&file_lock);
    return i;
   
}

int write(int fd, const void *buffer, unsigned size)
{
    check_user_vaddr(buffer);
    lock_acquire(&file_lock);
    int ret = -1;

    if (fd ==1) {
        putbuf((char*)buffer,(size_t)size)  ;
        ret = size;
    }
    else if(fd>2) {
        if (thread_current()->fd[fd] == NULL) {
            lock_release(&file_lock);
            exit(-1);
        }
        if (thread_current()->fd[fd]->deny_write){
            file_deny_write(thread_current()->fd[fd]);
        }

        ret = file_write(thread_current()->fd[fd],buffer,size);
    }
    
    lock_release(&file_lock);
    return ret;
    
}

void seek(int fd, unsigned position){
    if (thread_current()->fd[fd] == NULL) exit(-1);

    file_seek(thread_current()->fd[fd], position);
}
unsigned tell(int fd){
    if (thread_current()->fd[fd] == NULL) exit(-1);
    return file_tell(thread_current()->fd[fd]);
}
void close(int fd){
    struct file*fp = thread_current()->fd[fd];

    if (fp  == NULL) exit(-1);
    thread_current()->fd[fd] = NULL;
    return file_close(fp);
}

int fibonacci(int a){
    if(a==0) return 0;
    else if (a==1) return 1;
    else return fibonacci(a-1)+fibonacci(a-2);
}

int max_of_four_int(int a, int b, int c ,int d){

    
    int max = a;

    if(max < b)  max = b;
    if(max < c) max = c;
    if(max <d) max= d;
    return max;


}
